Step 1:- copy the github repo url

Step 2:- open cmd terminal 

Step3:- Git clone repo_url

Step 5:- open the folder
               unzip frontend 
               Unzip backend

Step6:- Go back to main folder. 

Step7:- right click open in terminal 

Step 8:- code .

Step9:- move to frontend
            npm install 
            npm run dev

Step10:- move backend
          npm install 
          npm start
